<?php

error_reporting( E_ALL | E_STRICT );

require_once __DIR__.'/vendor/SplClassLoader.php';

$loader = new SplClassLoader('Diggin', dirname(__DIR__).'/src/');
$loader->register();

